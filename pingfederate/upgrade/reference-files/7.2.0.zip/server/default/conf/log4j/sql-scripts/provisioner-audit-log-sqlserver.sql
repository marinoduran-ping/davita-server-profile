# ------------------------------------------------------------
# Create table provisioner_audit_log
# ------------------------------------------------------------

CREATE TABLE provisioner_audit_log
(
	id         int NOT NULL IDENTITY (1, 1),
	dtime      datetime NULL,
    cycle_id       varchar(255) NULL,
    channel_id     varchar(255) NULL,
    event_type     varchar(25) NULL,
    source_id      varchar(255) NULL,
    target_id      varchar(255) NULL,
    is_success      varchar(8) NULL,
    failure_cause    varchar(MAX) NULL
)  ON [PRIMARY]
GO

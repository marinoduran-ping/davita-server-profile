DROP TABLE channel_variable IF EXISTS;
CREATE TABLE channel_variable (
  channel INTEGER,
  name VARCHAR(255),
  value VARCHAR(255)
);

DROP TABLE channel_user IF EXISTS;
CREATE TABLE channel_user (
  channel INT,
  dsGuid VARCHAR(255),
  saasGuid VARCHAR(255),
  saasUsername VARCHAR(255),
  valuesHash VARCHAR(32),
  inGroup INT,
  dirty INT,
  saasIdentity LONGVARCHAR,
  created TIMESTAMP,
  modified TIMESTAMP,
  CONSTRAINT saasusernameunique UNIQUE(channel,saasusername)
);

DROP TABLE channel_group IF EXISTS;
CREATE TABLE channel_group (
  channel INT,
  dsGuid VARCHAR(255),
  saasGuid VARCHAR(255),
  saasGroupName VARCHAR(255),
  valuesHash VARCHAR(32),
  inGroup INT,
  dirty INT,
  saasGroup LONGVARCHAR,
  created TIMESTAMP,
  modified TIMESTAMP,
  CONSTRAINT saasgroupnameunique UNIQUE(channel,saasgroupname)
);
